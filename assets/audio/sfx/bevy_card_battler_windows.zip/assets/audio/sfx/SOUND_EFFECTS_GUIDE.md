# 游戏音效资源获取指南

> **状态**: 音效占位符待替换
> **测试文件**: `tests/sound_effects_tdd.rs`
> **更新日期**: 2026-01-29

---

## 📋 音效对照表

### 卡牌相关音效

| 音效ID | 中文名称 | 文件名 | 时长 | 推荐来源 | 状态 |
|--------|----------|--------|------|----------|------|
| `CardPlay` | 出牌音效 | `card_play.ogg` | 0.5-1s | 动漫卡牌出牌声 | ⏳ 占位符 |
| `DrawCard` | 抽牌音效 | `draw_card.ogg` | 0.3-0.5s | 扑克牌抽牌声 | ⏳ 占位符 |
| `ShuffleCard` | 洗牌音效 | `shuffle_card.ogg` | 0.5-1s | 扑克牌洗牌声 | ⏳ 占位符 |
| `CardHover` | 卡牌悬停 | `card_hover.ogg` | 0.2-0.3s | 轻微魔法声 | ⏳ 占位符 |
| `CardSelect` | 卡牌选中 | `card_select.ogg` | 0.3-0.5s | 确认提示音 | ⏳ 占位符 |

### 战斗相关音效

| 音效ID | 中文名称 | 文件名 | 时长 | 推荐来源 | 状态 |
|--------|----------|--------|------|----------|------|
| `PlayerAttack` | 玩家攻击 | `player_attack.ogg` | 0.5-1s | 武器挥砍/剑击声 | ⏳ 占位符 |
| `PlayerHit` | 玩家受击 | `player_hit.ogg` | 0.3-0.5s | 受伤呻吟/撞击声 | ⏳ 占位符 |
| `EnemyHit` | 敌人受击 | `enemy_hit.ogg` | 0.3-0.5s | 打击音效 | ⏳ 占位符 |
| `Block` | 格挡音效 | `block.ogg` | 0.3-0.5s | 金属/盾牌格挡声 | ⏳ 占位符 |
| `CriticalHit` | 暴击音效 | `critical_hit.ogg` | 0.5-1s | 强力打击+重击声 | ⏳ 占位符 |
| `Dodge` | 闪避音效 | `dodge.ogg` | 0.3-0.5s | 风声/快速移动声 | ⏳ 占位符 |

### 法术/技能音效

| 音效ID | 中文名称 | 文件名 | 时长 | 推荐来源 | 状态 |
|--------|----------|--------|------|----------|------|
| `LightningStrike` | 天雷落下 | `lightning_strike.ogg` | 1-2s | 雷声+电击声 | ⏳ 占位符 |
| `FireSpell` | 火焰法术 | `fire_spell.ogg` | 0.5-1s | 火焰燃烧声 | ⏳ 占位符 |
| `IceSpell` | 冰霜法术 | `ice_spell.ogg` | 0.5-1s | 冰冻破碎声 | ⏳ 占位符 |
| `Heal` | 治疗音效 | `heal.ogg` | 0.5-1s | 圣光/恢复声 | ⏳ 占位符 |
| `BuffApply` | 增益施加 | `buff_apply.ogg` | 0.3-0.5s | 能量上升声 | ⏳ 占位符 |
| `DebuffApply` | 减益施加 | `debuff_apply.ogg` | 0.3-0.5s | 负面魔法声 | ⏳ 占位符 |
| `ShieldUp` | 护盾升起 | `shield_up.ogg` | 0.3-0.5s | 能量护盾声 | ⏳ 占位符 |

### 大招/终极技能音效

| 音效ID | 中文名称 | 文件名 | 时长 | 推荐来源 | 状态 |
|--------|----------|--------|------|----------|------|
| `UltimateStart` | 大招起手 | `ultimate_start.ogg` | 1-2s | 能量聚集+前摇 | ⏳ 占位符 |
| `UltimateRelease` | 大招释放 | `ultimate_release.ogg` | 2-3s | 强力爆发声 | ⏳ 占位符 |
| `SwordStrike` | 剑气斩击 | `sword_strike.ogg` | 1-2s | 剑气破空声 | ⏳ 占位符 |
| `ThousandSwords` | 万剑归宗 | `thousand_swords.ogg` | 3-5s | 多重剑击+华丽爆发 | ⏳ 占位符 |

### UI交互音效

| 音效ID | 中文名称 | 文件名 | 时长 | 推荐来源 | 状态 |
|--------|----------|--------|------|----------|------|
| `UiClick` | UI点击 | `ui_click.ogg` | 0.1-0.2s | 清脆点击声 | ⏳ 占位符 |
| `UiHover` | UI悬停 | `ui_hover.ogg` | 0.1-0.15s | 轻微提示音 | ⏳ 占位符 |
| `UiConfirm` | UI确认 | `ui_confirm.ogg` | 0.2-0.3s | 肯定/成功提示 | ⏳ 占位符 |
| `UiCancel` | UI取消 | `ui_cancel.ogg` | 0.2-0.3s | 取消/返回提示 | ⏳ 占位符 |
| `UiError` | UI错误 | `ui_error.ogg` | 0.3-0.5s | 错误/失败提示 | ⏳ 占位符 |

### 系统/事件音效

| 音效ID | 中文名称 | 文件名 | 时长 | 推荐来源 | 状态 |
|--------|----------|--------|------|----------|------|
| `BreakthroughStart` | 突破开始 | `breakthrough_start.ogg` | 1-2s | 能量聚集声 | ⏳ 占位符 |
| `BreakthroughSuccess` | 突破成功 | `breakthrough_success.ogg` | 2-3s | 成功+升级声 | ⏳ 占位符 |
| `LevelUp` | 升级音效 | `level_up.ogg` | 1-2s | 升级+正反馈 | ⏳ 占位符 |
| `GoldGain` | 获得金币 | `gold_gain.ogg` | 0.5-1s | 金币掉落声 | ⏳ 占位符 |
| `RelicObtain` | 获得遗物 | `relic_obtain.ogg` | 1-2s | 稀有物品获得 | ⏳ 占位符 |
| `Victory` | 战斗胜利 | `victory.ogg` | 2-3s | 胜利欢呼/正反馈 | ⏳ 占位符 |
| `Defeat` | 战斗失败 | `defeat.ogg` | 2-3s | 失败音效 | ⏳ 占位符 |

### 敌人相关音效

| 音效ID | 中文名称 | 文件名 | 时长 | 推荐来源 | 状态 |
|--------|----------|--------|------|----------|------|
| `EnemySpawn` | 敌人生成 | `enemy_spawn.ogg` | 0.5-1s | 出现/召唤声 | ⏳ 占位符 |
| `EnemyDeath` | 敌人死亡 | `enemy_death.ogg` | 0.5-1s | 死亡/消散声 | ⏳ 占位符 |
| `BossAppear` | Boss登场 | `boss_appear.ogg` | 2-3s | Boss威压+登场 | ⏳ 占位符 |
| `BossDeath` | Boss死亡 | `boss_death.ogg` | 3-5s | Boss死亡+华丽消散 | ⏳ 占位符 |

---

## 🔗 推荐音效资源网站

### 免费音效网站

| 网站 | URL | 说明 |
|------|-----|------|
| **Freesound** | https://freesound.org | 最大的免费音效库，需注册 |
| **Zapsplat** | https://www.zapsplat.com | 大量免费音效，需署名 |
| **Mixkit** | https://mixkit.co/free-sound-effects | 免费音效，无需署名 |
| **Pixabay** | https://pixabay.com/sound-effects | 免费音效和音乐 |
| **OpenGameArt** | https://opengameart.org | 游戏音效资源 |
| ** Sonniss** | https:// Sonniss.com | 年度免费音效包 |

### 付费音效网站

| 网站 | URL | 说明 |
|------|-----|------|
| **AudioJungle** | https://audiojungle.net | Envato市场，音效质量高 |
| **Pond5** | https://www.pond5.com | 专业音效库 |
| **Epidemic Sound** | https://www.epidemicsound.com | 订阅制，商用友好 |

### 中国音效网站

| 网站 | URL | 说明 |
|------|-----|------|
| **爱给网** | https://www.aigei.com | 中文音效资源站 |
| **配音秀** | https://www.peiyinxiu.com | 音效和配音资源 |
| **淘声网** | https://www.tosound.com | 免费音效搜索 |

---

## 📝 音效搜索关键词

### 通用关键词
- `chinese fantasy` `wuxia` `xianxia` `martial arts`
- `sword` `magic` `spell` `impact` `whoosh`
- `game sfx` `rpg sfx` `ui sfx`

### 特定搜索
- `card draw sound` `shuffle cards` `card play`
- `sword attack` `fire spell` `ice spell` `lightning`
- `heal magic` `buff sound` `shield up`
- `level up` `victory` `boss death` `gold coin`

---

## 🔧 音效编辑建议

### 推荐工具

| 工具 | 平台 | 用途 |
|------|------|------|
| **Audacity** | 跨平台 | 免费，基础编辑 |
| **Adobe Audition** | Win/Mac | 专业音频编辑 |
| **GarageBand** | macOS | Mac自带，简单编辑 |
| **Ocenaudio** | 跨平台 | 轻量级音频编辑 |

### 编辑要点

1. **格式**: 统一转换为 OGG Vorbis 格式
2. **采样率**: 44.1kHz 或 48kHz
3. **比特率**: 192-320 kbps
4. **声道**: 立体声
5. **音量**: 标准化至 -3dB 到 -1dB
6. **长度**: 根据对照表要求裁剪
7. **淡入淡出**: 头尾添加 0.01-0.05秒淡入淡出，避免爆音

---

## 📁 文件结构

```
assets/audio/sfx/
├── 卡牌相关/
│   ├── card_play.ogg
│   ├── draw_card.ogg
│   ├── shuffle_card.ogg
│   ├── card_hover.ogg
│   └── card_select.ogg
├── 战斗相关/
│   ├── player_attack.ogg
│   ├── player_hit.ogg
│   ├── enemy_hit.ogg
│   ├── block.ogg
│   ├── critical_hit.ogg
│   └── dodge.ogg
├── 法术技能/
│   ├── lightning_strike.ogg
│   ├── fire_spell.ogg
│   ├── ice_spell.ogg
│   ├── heal.ogg
│   ├── buff_apply.ogg
│   ├── debuff_apply.ogg
│   └── shield_up.ogg
├── 大招技能/
│   ├── ultimate_start.ogg
│   ├── ultimate_release.ogg
│   ├── sword_strike.ogg
│   └── thousand_swords.ogg
├── UI交互/
│   ├── ui_click.ogg
│   ├── ui_hover.ogg
│   ├── ui_confirm.ogg
│   ├── ui_cancel.ogg
│   └── ui_error.ogg
├── 系统事件/
│   ├── breakthrough_start.ogg
│   ├── breakthrough_success.ogg
│   ├── level_up.ogg
│   ├── gold_gain.ogg
│   ├── relic_obtain.ogg
│   ├── victory.ogg
│   └── defeat.ogg
└── 敌人相关/
    ├── enemy_spawn.ogg
    ├── enemy_death.ogg
    ├── boss_appear.ogg
    └── boss_death.ogg
```

---

## 🔄 替换流程

### 1. 下载音效文件
从推荐网站下载对应的音效文件

### 2. 编辑处理
使用 Audacity 等工具进行格式转换和裁剪

### 3. 放置文件
将处理好的文件放入 `assets/audio/sfx/` 对应目录

### 4. 移除占位符
运行脚本移除代码中的占位符：
```bash
./scripts/replace_sfx_placeholders.sh
```

### 5. 验证测试
```bash
# 运行TDD测试
cargo test --test sound_effects_tdd

# 运行游戏测试
cargo run
```

---

## ⚠️ 版权说明

- 免费音效请确认使用许可（CC0、BY、BY-NC等）
- 商用游戏请使用无署名要求或已购买授权的音效
- 建议记录每个音效的来源和许可信息
- 避免使用受版权保护的知名游戏音效

---

## 📊 进度跟踪

| 分类 | 总数 | 已完成 | 待替换 | 完成率 |
|------|------|--------|--------|--------|
| 卡牌相关 | 5 | 0 | 5 | 0% |
| 战斗相关 | 6 | 0 | 6 | 0% |
| 法术技能 | 7 | 0 | 7 | 0% |
| 大招技能 | 4 | 0 | 4 | 0% |
| UI交互 | 5 | 0 | 5 | 0% |
| 系统事件 | 7 | 0 | 7 | 0% |
| 敌人相关 | 4 | 0 | 4 | 0% |
| **总计** | **38** | **0** | **38** | **0% |
